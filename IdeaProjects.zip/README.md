# game-betslip-check-api

## 对账系统api模块

* 已对代码进行了通用化调整 (产品线, 货币等)

* 部署范围不限于单个产品线 (如 C66) 

