package net.tbu.spi.strategy.channel.dto;

import org.junit.jupiter.api.Test;

class LobbyInverseOrderQueryTest {

    @Test
    void formAndPlus() {



    }

    @Test
    void splitTime() {
    }

    @Test
    void from() {
    }

}