package net.tbu.spi.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import net.tbu.spi.entity.TReconciliationBatch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 对账批次表 Mapper 接口
 * </p>
 *
 * @author hao.yu
 * @since 2024-12-24
 */

@Mapper
public interface TReconciliationBatchMapper extends BaseMapper<TReconciliationBatch> {

    @Select("SELECT MAX(BATCH_NUMBER) FROM T_RECONCILIATION_BATCH")
    String selectMaxBatchNumber();
}
