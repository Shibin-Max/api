package net.tbu.spi.strategy.channel.dto.rts;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RTSDealer {
    private String uid;
    private String name;
}
