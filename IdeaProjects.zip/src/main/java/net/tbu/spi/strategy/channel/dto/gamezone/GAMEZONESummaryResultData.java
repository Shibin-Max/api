package net.tbu.spi.strategy.channel.dto.gamezone;

import lombok.Data;

@Data
public class GAMEZONESummaryResultData {

    private String start;
    private String end;
    private GAMEZONESummaryResult summary;

}
