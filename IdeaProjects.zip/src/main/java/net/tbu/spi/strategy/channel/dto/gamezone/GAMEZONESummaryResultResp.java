package net.tbu.spi.strategy.channel.dto.gamezone;

import lombok.Data;

@Data
public class GAMEZONESummaryResultResp {

    private Integer code;
    private String msg;
    private GAMEZONESummaryResultData data;

}
